public class car
{
	public static void main(String[] middle)
	{
		System.out.println("BMW Airlines.");
		System.out.println("M3 Competition.");
	}
}