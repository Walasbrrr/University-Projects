import java.util.Scanner

public class FinancialAid
