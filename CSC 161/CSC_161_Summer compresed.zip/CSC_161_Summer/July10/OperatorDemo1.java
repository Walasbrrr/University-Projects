public class OperatorDemo1
{
	public static void main(String[] ar)
		{
			int result;
			result=18;

			System.out.println("Ifyou divide 18 by 7, you get " +  result/7);
			System.out.println("The remainder of dividing 18 by 7 is 18%7")
		}
}