public class VarDemo2
{
	public static void main(String[] args)
	{
		//This line is called: the DECLARATION STATMENT
		int num1;
		
		//The following lines is an "ASSIGNMENT STATMENT"
		num1=3;

		System.out.println( "There are " + num1 + " students.");
		
		num1=19;
		
		System.out.println("On Monday there were" + num1 + " students.");
	}
}