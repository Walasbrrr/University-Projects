import java.util.Scanner;
import java.text.DecimalFormat;

public class Sneaker
{
	public static void main(String[] args)
	{
		int sneakers;
		double price, tax, result; //Compound declaration
		DecimalFormat f = new DecimalFormat("#.00");
		Scanner kb = new Scanner( System.in);
		
		System.out.print("How many sneakers? ");
		sneakers = kb.nextInt();

		System.out.print("Price for 1 sneaker: ");
		price=kb.nextDouble();

		System.out.print("Enter tax: ");
		tax=kb.nextDouble();
		result=(1+tax)*price*sneakers;

		System.out.println("If you buy" + sneakers + " sneakers, you owe $" + f.format(result));

	} //end of method main
}// end of class