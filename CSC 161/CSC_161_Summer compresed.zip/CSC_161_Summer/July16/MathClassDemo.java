import java.util.Scanner;
import java.text.DecimalFormat;
import java.lang.Math;


public class MathClassDemo
{
	public static void main(String[] p)
	{
		DecimalFormat m = new DecimalFormat("#.00");
		Scanner inp = new Scanner( System.in);

		double radius, area;
		
		System.out.print("Enter radius: ");
		radius = inp.nextDouble();

		area = Math.PI * Math.pow( radius , 2 );
		System.out.println("A circle with radius " + radius + "has an area of: " + 					m.format(area) );

		double result;
		result = Math.pow(2.3 , 1.7);
		System.out.println("If you raise 2.3 to the power of 1.7, you get: " + result);
		
		double theValue;
		theValue = Math.sqrt(7.2);
		System.out.println("The square root of 7.2 is : " + m.format(theValue) );

		//How to calculate the sine of 30 degrees:
		angle=30/180 * Math.PI;   // Converts 30 degrees into radians
		r = Math.sin( angle );
		System.out.println("The sine of 30 degrees is: " + r );



	} // end of method main
} // end of class