/*
	Author: Yoosuf Faiz
	date: 07/22/2024
	Assignment name: Inclass Lab3(Program2)
	Name of the instructor: Vickram Sawh
	Course: CSC_161-Intro to Comp.Sci using Java
*/

import java.util.Scanner;

public class Trig
{
	public static void main(String[] args)
	{
		Scanner inp = new Scanner(System.in);
		System.out.print("Enter an angle in degrees: ");

		double Degrees;
		double Radians;
		Degrees = inp.nextDouble();
		Radians = Math.toRadians(Degrees);

		double sine;
		double cosine;
		double tangent;

		sine = Math.sin(Radians);
		cosine = Math.cos(Radians);
		tangent = Math.tan(Radians);

		System.out.println("Sine of the degree " + Degrees + " is " + sine );
		System.out.println("Cosine of the degree " + Degrees + " is " + cosine);
		System.out.println("Tangent of the degree " + Degrees + " is " + tangent);

		} // end of method main
} // end of class