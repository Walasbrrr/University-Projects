/*
	Author: Yoosuf Faiz
	date: 07/22/2024
	Assignment name: Inclass Lab3(Program4)
	Name of the instructor: Vickram Sawh
	Course: CSC_161-Intro to Comp.Sci using Java
*/

import java.util.Scanner;

public class MathMethods
{
	public static void main(String[] args)
	{
		Scanner inp = new Scanner(System.in);
		System.out.println("Enter an integer value: ");
		int Value;
		double logValue;

		Value = inp.nextInt();
		logValue = Math.log(Value);

		System.out.println("log(" + Value + ") = " +logValue);
		System.out.println("Value = " + Value);

	}
}