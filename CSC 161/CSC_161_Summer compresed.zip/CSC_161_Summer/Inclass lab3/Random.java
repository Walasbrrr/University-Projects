/*
	Author: Yoosuf Faiz
	date: 07/22/2024
	Assignment name: Inclass Lab3(Program3)
	Name of the instructor: Vickram Sawh
	Course: CSC_161-Intro to Comp.Sci using Java
*/
import java.lang.Math;

public class Random
{
		public static void main(String[] args)
		{
			double randomNumber , roundedNumber;
			randomNumber = Math.random();
			roundedNumber = Math.round(randomNumber * 100000)/ 100000;

			System.out.println("Random number rounded up to 5 decimal places: " + roundedNumber);

		}

}
