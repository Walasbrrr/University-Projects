/*
	Author: Yoosuf Faiz
	date: 07/22/2024
	Assignment name: Inclass Lab2(Program1)
	Name of the instructor: Vickram Sawh
	Course: CSC_161-Intro to Comp.Sci using Java
*/

import java.util.Scanner;

public class SquareRoot
{
	public static void main(String[] args)
	{
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter a real value: ");
		double thevalue;
		double squareRoot;

		thevalue = scanner.nextDouble();
		squareRoot = Math.sqrt(thevalue);

		System.out.println("The square root of the value " + thevalue + "is" + squareRoot);

	}
}