/*
	Author: Yoosuf Faiz
	Purpose: To explain what we have learned in the basics of Java programming
	date: 07/11/2024
	Name of the instructor: Vickram Sawh
	Course: CSC_161-Intro to Comp.Sci using Java 
*/
public class Closet
{
	public static void main(String[] L)
	{
		System.out.println("My\"closet\"");
		System.out.println("Shirts\t6");
		System.out.println("Jackets\t11");
		System.out.println("Socks\t32");
	}
}