/*
	Author: Yoosuf Faiz
	Purpose: To explain what we have learned in the basics of Java programming
	date: 07/11/2024
	Name of the instructor: Vickram Sawh
	Course: CSC_161-Intro to Comp.Sci using Java 
*/
public class Adress
{
	public static void main(String[] M)
		{
			System.out.println("Muhammed Yoosuf Mohamed Faiz");
			System.out.println("402 College Dr");
			System.out.println("Edison, NJ 08817");
		}
}