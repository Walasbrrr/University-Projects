import javax.swing.JOptionPane;


public class InputDialogBoxDemo
{
	public static void main(String[] agrs)
	{
		String theName;
		theName = JOptionPane.showInputDialog("Enter the Name Please: ");

		JOptionPane.showMessageDialog( null, "Glad to meet you " + theName );

		int age;
		String temp;
		temp = JOptionPane.showInputDialog("What is your age?  ");
		age = Integer.parseInt( temp );
		age+=5;
		JOptionPane.showInputDialog(null, "In 5 years you will be: " + age );

		double amount;
		temp = JOptionPane.showInputDialog("How much do you owe? ");
		amount = Double.parseDouble( temp );
		JOptionPane.showMessageDialog( null, "OK, you owe $" + amount );


	}// end of main
} // end of the class