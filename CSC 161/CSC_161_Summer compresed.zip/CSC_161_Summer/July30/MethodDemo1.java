public class MethodDemo1
{
	public static void main(String[] arge)
	{
		boolean result;
		result = isEven( 7 );
		System.out.println("The isEven method returns; " + result);
	}

public static boolean isEven(int bob)
{
	if( bob % 2 == 0)
	return true;
	else
	return false;
} // end of the method named isEven

public static void main(String[] args)
{
	boolean
}