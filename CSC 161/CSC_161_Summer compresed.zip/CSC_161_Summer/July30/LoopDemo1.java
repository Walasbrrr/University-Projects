public class LoopDemo1
{
	public static void main(String[] p)
	{
		while ( 1==1 )
		{
			System.out.println("Middlesex" );
		}
	}
}