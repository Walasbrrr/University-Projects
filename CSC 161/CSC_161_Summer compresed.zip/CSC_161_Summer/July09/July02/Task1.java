public class Task1
{	
	public static void main(String[] middle)
	{
		System.out.println("Hello Universe.");
	}
}