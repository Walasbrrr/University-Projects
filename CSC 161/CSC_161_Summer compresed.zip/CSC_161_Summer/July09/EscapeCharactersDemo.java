public class EscapeCharactersDemo
{
	public static void main(String[] p)
	{
		System.out.println("Middlesex");
		System.out.print("is");
		System.out.println("a great school.");

		System.out.println("Middlesexcc\nis\na great School.");
	 	System.out.print("Alexander\"the great\".");
		System.out.println("Shirts\t$40\t3");
		System.out.println("Tie\t$5\t7");
		System.out.println("Belts\t$10\t12");
		System.out.println("Hello\bWorlf");
	}
}