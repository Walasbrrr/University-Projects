public class VarableDemo1
{
	public static void main (String[] p)
	{
		System.out.println("There are 16 students.");

		System.out.println("There are " + 16 + "students.");
		
		int num1;
		num1=23;
		System.out.println("There are" + num1 + "students.");
	}
}