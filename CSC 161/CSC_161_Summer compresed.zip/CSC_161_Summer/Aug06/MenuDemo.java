import java.util.Scanner;

public class MenuDemo
{
	public static void main(String[] args)
	{
		int option; // holds the user's input
		Scanner i = new Scanner( System.in );

		System.out.println("1. CM to IN\n2.IN to CM\n3.Exit\nEnter option: ");
		option = i.nextInt();
		while ( option != 3)
		{
			if ( option == 1 )
			{
				System.out.println("You choose option 1.");

			}
			else
			{
				if ( option ==2)
				{
					System.out.println("You choose option 2.");
				}
				else
				{
					System.out.println("Invalid option. please retry.");
				}

		}

			System.out.print("1. CM to IN\n2.IN to CM\n3.Exit\nEnter option: ");
			option = i.nextInt();
		} // end of the while

	}
