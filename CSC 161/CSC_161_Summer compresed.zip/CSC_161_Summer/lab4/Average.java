/*
	Author: Yoosuf Faiz
	date: 08/04/2024
	Assignment name: Inclass Lab4(Program3)
	Name of the instructor: Vickram Sawh
	Course: CSC_161-Intro to Comp.Sci using Java
*/

import java.util.Scanner;

public class Average
{
    public static void main(String[] args)
    {
        Scanner inp = new Scanner(System.in);

        // 4 whole number values
        System.out.print("Enter first number: ");
        int firstNumber;
        firstNumber= inp.nextInt();
        System.out.print("Enter second number: ");
        int secondNumber;
        secondNumber= inp.nextInt();
        System.out.print("Enter third number: ");
        int thirdNumber;
        thirdNumber= inp.nextInt();
        System.out.print("Enter final number: ");
        int finalNumber;
        finalNumber= inp.nextInt();

        //  average
        double average = (firstNumber + secondNumber + thirdNumber + finalNumber) / 4.0;

        // Print the result
        System.out.println("The average of " + firstNumber + ", " + secondNumber + ", " + thirdNumber + " and " + finalNumber + " is: " + average);
    }
}
