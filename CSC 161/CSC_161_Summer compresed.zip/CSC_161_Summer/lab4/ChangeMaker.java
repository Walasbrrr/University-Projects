/*
	Author: Yoosuf Faiz
	date: 08/04/2024
	Assignment name: Inclass Lab4(Program1)
	Name of the instructor: Vickram Sawh
	Course: CSC_161-Intro to Comp.Sci using Java
*/

import java.util.Scanner;

public class ChangeMaker
{
    public static void main(String[] args)
    {
        Scanner inp = new Scanner(System.in);


        System.out.print("Enter the number of pennies: ");
        int pennies = inp.nextInt();


        int TPennies = pennies;


        int quarters = pennies / 25;
        pennies = pennies % 25;
        int dimes = pennies / 10;
        pennies = pennies % 10;
        int nickels = pennies / 5;
        pennies = pennies % 5;

        // Print the result
        System.out.println(TPennies + " pennies = " + quarters + " quarters, " + dimes + " dimes, " + nickels + " nickels and " + pennies + " pennies");
    }
}
