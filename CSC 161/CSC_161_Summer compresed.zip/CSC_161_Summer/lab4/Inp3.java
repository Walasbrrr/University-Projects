/*
	Author: Yoosuf Faiz
	date: 08/04/2024
	Assignment name: Inclass Lab3(Program5)
	Name of the instructor: Vickram Sawh
	Course: CSC_161-Intro to Comp.Sci using Java
*/

import javax.swing.JOptionPane;

public class Inp3 {
    public static void main(String[] args) {
        // Ask the user for their name
        String name;
        name = JOptionPane.showInputDialog("Enter your name:");

        // Ask the user for their street address
        String address;
        address = JOptionPane.showInputDialog("Enter your street address:");

        // Ask the user for a real value
        String realValueStr;
        realValueStr = JOptionPane.showInputDialog("Enter a real value:");
        double realValue;
        realValue = Double.parseDouble(realValueStr);

        // Compute square root, multiplied values, and their square roots
        double sqrtValue;
        sqrtValue = Math.sqrt(realValue);
        double doubledValue;
        doubledValue = realValue * 2;
        double sqrtDoubledValue;
        sqrtDoubledValue = Math.sqrt(doubledValue);
        double quadrupledValue;
        quadrupledValue = realValue * 4;
        double sqrtQuadrupledValue;
        sqrtQuadrupledValue = Math.sqrt(quadrupledValue);

        //create message
