/*
	Author: Yoosuf Faiz
	date: 08/04/2024
	Assignment name: Inclass Lab4(Program4)
	Name of the instructor: Vickram Sawh
	Course: CSC_161-Intro to Comp.Sci using Java
*/

import java.util.Scanner;

public class Circle
{
    public static void main(String[] args)
    {
        final double PI = Math.PI;
        final int DECIMALS = 14;

        Scanner inp = new Scanner(System.in);

        // radius of the circle
        System.out.print("Enter the radius for the circle: ");
        double radius;
        radius = inp.nextDouble();

        // circumference and area of the circle
        double circumference;
        circumference = 2 * PI * radius;
        double area;
        area = PI * Math.pow(radius, 2);

        // Format the results to 14 decimal places
        String areaFormatted = String.format("%." + DECIMALS + "f", area);
	    String circumferenceFormatted = String.format("%." + DECIMALS + "f", circumference);

		 // Print the result
		 System.out.println("A circle with a radius of " + radius + " is " + areaFormatted + " square inches, and has a circumference of " + circumferenceFormatted + " inches");
		    }
}