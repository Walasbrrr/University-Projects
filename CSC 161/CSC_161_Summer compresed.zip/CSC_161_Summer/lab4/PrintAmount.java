/*
	Author: Yoosuf Faiz
	date: 08/04/2024
	Assignment name: Inclass Lab4(Program2)
	Name of the instructor: Vickram Sawh
	Course: CSC_161-Intro to Comp.Sci using Java
*/

import java.util.Scanner;

public class PrintAmount
{
    public static void main(String[] args)
    {
        Scanner inp = new Scanner(System.in);


        System.out.print("Enter an amount of money ? $ ");
        String amount = inp.nextLine();


        String[] parts = amount.split("\\.");
        int dollars = Integer.parseInt(parts[0]);
        int cents = Integer.parseInt(parts[1]);

        // Print the result
        System.out.println("$ " + amount + " is equal to: " + dollars + " dollars, and " + cents + " cents.");
    }
}
