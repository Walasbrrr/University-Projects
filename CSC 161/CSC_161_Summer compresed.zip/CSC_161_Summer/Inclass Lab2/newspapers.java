/*
	Author: Yoosuf Faiz
	date: 07/17/2024
	Assignment name: Inclass Lab2(Program1)
	Name of the instructor: Vickram Sawh
	Course: CSC_161-Intro to Comp.Sci using Java 
*/


import java.util.Scanner;

public class newspapers
{
	public static void main(String[] args)
	{
		int newspapers;
		int sold;
		int totalcost;
	
		Scanner kb = new Scanner ( System.in);

		System.out.print("What is the cost for a newspaper? ");
		newspapers = kb.nextInt();

		System.out.print("Enter newspapers sold: ");
		sold = kb.nextInt();

		totalcost = newspapers * sold;
		System.out.print("The total cost for the newspapers is " + totalcost + " cents");
	}
}