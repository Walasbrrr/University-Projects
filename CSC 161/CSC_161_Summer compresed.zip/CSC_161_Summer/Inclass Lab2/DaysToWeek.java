/*
	Author: Yoosuf Faiz
	date: 07/17/2024
	Assignment name: Inclass Lab2(Program1)
	Name of the instructor: Vickram Sawh
	Course: CSC_161-Intro to Comp.Sci using Java 
*/

import java.util.Scanner;

public class DaysToWeek
{
	public static void main(String[] args)
	{	
		int days;
		int weeks;
		int balancedays;
		 
		Scanner kb = new Scanner (System.in);
		
		System.out.print("Enter the num of days: ");
		days = kb.nextInt();
		weeks = days / 7.nextInt();
		balancedays = days % 7.nextInt();

		System.out.println(days +" days represents " + weeks + " whole weeks and " + balancedays + " days.");
		
	

		
		
		
	} 
}