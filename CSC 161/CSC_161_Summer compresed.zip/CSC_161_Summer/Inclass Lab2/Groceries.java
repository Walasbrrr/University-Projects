/*
	Author: Yoosuf Faiz
	date: 07/17/2024
	Assignment name: Inclass Lab2(Program1)
	Name of the instructor: Vickram Sawh
	Course: CSC_161-Intro to Comp.Sci using Java 
*/

import java.util.Scanner;

public class Groceries
{
	public static void main(String[] args)
	{
		int apples;
		int bananas;
		int priceofoneapple;
		int priceofwholepoundbananas;
		int totalcostapples;
		int totalcostwholepoundbananas;
		int totalcost;

		Scanner kb = new Scanner (System.in);	
		
		System.out.print("Enter the number of apples: ");
		apples = kb.nextInt();
		
		System.out.print("Enter the number of whole pound  of bananas picked: ");
		bananas = kb.nextInt();

		System.out.print("Enter the price of one apple: ");
		priceofoneapple = kb.nextInt();

		System.out.print("Enter the price of a whole pound of bananas: ");
		priceofwholepoundbananas = kb.nextInt();

		totalcostapples = apples * priceofoneapple;
		totalcostwholepoundbananas = bananas * priceofwholepoundbananas;
		totalcost = totalcostapples * totalcostwholepoundbananas;
		
		System.out.print("The total cost for the apples and bananas: " + totalcost);
	} // end of method main
} //end of class
		