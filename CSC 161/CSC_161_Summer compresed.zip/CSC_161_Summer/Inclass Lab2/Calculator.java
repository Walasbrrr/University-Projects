/*
	Author: Yoosuf Faiz
	date: 07/17/2024
	Assignment name: Inclass Lab2(Program1)
	Name of the instructor: Vickram Sawh
	Course: CSC_161-Intro to Comp.Sci using Java 
*/

import java.util.Scanner;

public class Calculator
{
	public static void main(String[] args)
		{
			Scanner kb = new Scanner (System.in);
			
			int number1, number 2, sum, difference, product, quotient, remainder;
 		System.out.print("Enter number 1: ");
		number1 = kb.nextInt();
