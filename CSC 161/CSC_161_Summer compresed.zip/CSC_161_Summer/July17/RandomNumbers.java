import java.lang.Math;

public class RandomNumbers
{
	public static void main(String[] args)
	{
		double randomNumber, num;
		randomNumber = Math.random();
		num = randomNumber * 10;

		  int num2;
		  num2= (int) num;

		   num2   =  (num2 % 6) + 1;
		System.out.println("The random number is: " + num2);
	}
}