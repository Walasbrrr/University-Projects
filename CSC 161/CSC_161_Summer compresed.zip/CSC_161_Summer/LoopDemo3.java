public class LoopDemo3
{
	public static void main(String[] args)
	{
		//The initialization, condition and
		//increment in a for-loop are optional.
		//with an Infinite loop
		//  for( ; ; )
		// {
		//		System.out.print("BMW");
		// }


		int counter;
		for ( counter=0 ; counter < 3 ; counter++ )
		{
			System.out.println("BMW");
		}
		System.out.println("GoodBye.");
	}
}