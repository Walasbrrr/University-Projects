public class FlushingTheInputBuffer
{
	public static void main (String[] args)
	{
		Scanner d = new Scanner(system.in);
		int age;
		String name;

		//Ask for the user's age:
		System.out.print("Enter your age: ");
		age = i.nextInt();

		// The following line clears the newline character
		//left behind in the input buffer by nextInt()
		i.nextLine();

		//Aks for the user's name:
		System.out.print("Enter your name: ")
		name = i.nestLine();


		//Echo on the screen the uer's info:
		System.out.println(




	} // end of main

} //end of the class