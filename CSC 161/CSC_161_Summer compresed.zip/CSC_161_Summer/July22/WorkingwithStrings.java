import java.util.Scanner;

public class WorkingwithStrings
{
	public static void main(String[] args)
	{
		Scanner k = new Scanner(System.in);

		String firstName;
		firstName="Micheal Jackson";
		System.out.println(firstName + " was a singer in 80s");

		String name;
		System.out.println("What is your name? ");
		name = k.nextLine(); //The nextLine() is the Scanner class, allows
							 // you to read in text in text up to the new line character.
		System.out.println("Hello " + name + ". Glad to meet you!");

		//The length() method in the String class returns the number of characters
		// in the STirng.
		String fname;
		System.out.println("I will guess the numbers of characters in your name. What is it? ");
		fname = k. nextLine();
		int numcharacters;
		numcharacters = fname.length();
		System.out.print("Ok" + fname + ". Your name has " + numcharacters + "characters." );
		//The 3 line above, could have been "condensed" into:
		// System.out.print("OK " + fname + ". Your name has " + fname.length() + " characters.");

		char charIn3rdSpot;
		charIn3rdSpot = fname.charAt(2);
		System.out.println("The character in the 3rd spot of your name is: " + charIn3rdSpot);
		System.out.println("The 1st character is: " + fname.charAt(0) );
		System.out.println("The last character is: " +   fname.charAt( fname.length()-1) );
		System.out.println("The character a appears at index: " + fname.indexOf


		} // end of method main

}	// end of method calss


