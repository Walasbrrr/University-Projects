import java.util.Scanner;

public class IfDemo1
{
	public static void main(String[] args)
	{
		int age;
		Scanner i = new Scanner(System.in);

		System.out.print("Enter your age: ");
		age = i.nextInt();
		if( age < 18)
		{

			System.out.println("You may not drive.");
		}
		else
		{
			if ( age == 18)  //The nested if-statement
			{
			System.out.println("Take the driving test." );
			}
			else
			{
				System.out.println("You may drive.");
			}

		}
			System.out.println("goodbye");
	}
}