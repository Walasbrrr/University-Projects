import javax.swing.JOptionpane;
import java.util.Scanner;
public class IfDemo5
{
	public static void main(String[] args)
	{
		int age;
		Scanner i = new Scanner(System.in);

		System.out.print("Enter your age: ");
		age = i.nextInt();
		if( age < 18)
		{

			JOptionpane.showMessageDialog(null,"You may not drive.");
		}
		else
		{
			if ( age == 18)  //The nested if-statement
			{
			JOptionpane.showMessageDialog(null,"Take the driving test." );
			}
			else
			{
				JOptionpane.showMessageDialog(null,"You may drive.");
			}

		}
			JOptionpane.showMessageDialog(null,"goodbye");
	}
}