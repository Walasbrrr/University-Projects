import java.util.Scanner


public class LoopDemo2
{
	public static void main(String[] args)
	{
		int num;
		num=0;
		while( num < 3 )
		{
			System.out.println("Middlesexcc");
			num++;

		}
		System.out.println("Edison" );
		System.out.println("The value of the loop counter after the 1st loop is; " + num);

		System.out.println("\n\n");
		//Alternative to the code above;
		while( num <= 3 )
		{
					System.out.println("Middlesexcc");
					num++;

		}
		System.out.println("Edison" );
		System.out.println("The value of the loop counter after the 2st loop is; " + num);
	}
}
