public class VarDemo3
{
	public static void main(String[] t)
	{
		int students;
		students=17;
		int state;
		state=students;
		System.out.println( "The variable -state- has: " + state );
		System.out.println("The variable -students- has: " + students );

		System.out.println("\n\n");

		int discount;
		int price;
		int k;
		price=44;
		k=7;
		discount = price + 8 * k;
		System.out.println( "The variable -discount- has: " + discount);
		System.out.println( "The variable -price- has: " + price);
		System.out.println( "The variable -k- has:" + k);

		System.out.println("\n\n");

		int houses;
		houses=14;
		System.out.println( "The variable -houses- before the assignment: " + houses);
		houses=houses /7;
		System.out.println( "The variable -houses- after the assignment: " + houses);
		System.out.println("\n\n");
		int score;
		score= 16;
		System.out.println( "The variable -score- has: " + score);
		score=score+1;
		System.out.println( "The variable -score- has: " + score);
		score=score+1;System.out.println( "The variable -score- has: " + score);
		score=score+1;System.out.println( "The variable -score- has: " + score);
		score=score+1;System.out.println( "The variable -score- has: " + score);
		score=score+1;System.out.println( "The variable -score- has: " + score);
		score=score+1;System.out.println( "The variable -score- has: " + score);
		score=score+1;System.out.println( "The variable -score- has: " + score);
		score=score+1;
		System.out.println( "The variable -score- has: " + score);
		score++;
		System.out.println( "The variable -score- has: " + score);
		++score;
		

	} //end of the method main



} //The end of the class