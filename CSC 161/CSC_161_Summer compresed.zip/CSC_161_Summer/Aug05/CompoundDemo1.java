public class CompundDemo1
{
	public static void main(String[] args)
	{
		double result;
		result = Compounding (100 ,0.04 ,3

	} // ed of class

	public static double Compounding( double base, double percent, int time)
	{
		int k=0;
		while ( k < time )
		{
			base += base * perrcent;
			k++;
		}
		return base;

	}

}// end of thee class

