import java.util.Scanner;
public class SumationDemo
{
	public static void main(String[] args)
	{
		int sum = 0, entry;
		Scanner i = new Scanner( System.in );

		System.out.print("Enter first number; " );
		entry = i.nextInt();
		while (entry !=0)
		{

			if ( isEven( entry) )
			{
				numEvens += 1;
			}
			else
			{
			}


			sum += entry;
 			System.out.print("Enter next number: ");
			entry=i.nextInt();
		}
		System.out.println("The sum is; " + sum);
	}// end of main


	public static boolean isEven( int bob )
	{
		if ( bob % 2== 0 )
		return true;
		else
		return false;
	 }


}