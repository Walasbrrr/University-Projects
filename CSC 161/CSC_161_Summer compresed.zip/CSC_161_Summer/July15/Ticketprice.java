import java.util.Scanner;

public class Ticketprice
{
	public static void main(String[] args)
	{
		//Thefollowing lines could have
		// combined as: int students,price,earnings;
		int students;
		int price;
		int earnings;

		//putting the methods in to the RAM
		Scanner kb = new Scanner( System.in);
		
		//Step1:
		System.out.print("Enter the number of students: ");
		students = kb.nextInt();

		//Step2: get the ticket price
		System.out.print("Enter the ticket prices");
		price = kb.nextInt();

		//Step3: calculate the earnings:
		earnings = students + price;

		//Step4: print the earnings:
		System.out.println("You earned " + earnings +" pennies.");
		
	}
}