import java.util.Scanner;

public class KeyboardInputDemo1
{
	public static void main (String[] p)
	{
		Scanner inp = new Scanner(System.in);
		int Students;
		System.out.print("How many students?");
		Students = inp.nextInt();
		System.out.println("there are " + Students + "in class");

	} // end of the method main
} // end of the class
